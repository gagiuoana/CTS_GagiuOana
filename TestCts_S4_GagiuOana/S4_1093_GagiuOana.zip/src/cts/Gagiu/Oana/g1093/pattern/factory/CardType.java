package cts.Gagiu.Oana.g1093.pattern.factory;

public enum CardType {
	
	CREDIT_CARD, DEBIT_CARD, JUNIOR_CARD

}
