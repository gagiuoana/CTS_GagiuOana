package cts.Gagiu.Oana.g1093.pattern.factory;

public class JuniorCard {
	
	
	String details;

	
	public JuniorCard(String details) {
		super();
		this.details = details;
	}

}
