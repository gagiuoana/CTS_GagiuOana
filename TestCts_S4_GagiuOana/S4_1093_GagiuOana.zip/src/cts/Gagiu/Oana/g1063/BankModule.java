package cts.Gagiu.Oana.g1063;

public abstract class BankModule {
    public abstract void processTransaction(String sourseAccount, 
    		String destinationAccount, double value,
            String destinationBank);
}